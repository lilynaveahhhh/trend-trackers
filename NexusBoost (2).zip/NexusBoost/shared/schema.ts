import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, real, timestamp, boolean, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const systemMetrics = pgTable("system_metrics", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
  cpuUsage: real("cpu_usage").notNull(),
  memoryUsage: real("memory_usage").notNull(),
  memoryTotal: real("memory_total").notNull(),
  gpuUsage: real("gpu_usage").notNull(),
  temperature: real("temperature").notNull(),
  batteryLevel: real("battery_level").notNull(),
  diskUsage: real("disk_usage").notNull(),
  diskTotal: real("disk_total").notNull(),
  networkType: text("network_type").notNull(), // '5G', '4G', 'WiFi'
  networkSpeed: real("network_speed").notNull(),
  processes: json("processes").$type<ProcessInfo[]>().notNull(),
});

export const optimizationSuggestions = pgTable("optimization_suggestions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
  type: text("type").notNull(), // 'thermal', 'network', 'process'
  description: text("description").notNull(),
  efficiency: real("efficiency").notNull(),
  autoApply: boolean("auto_apply").default(false),
  applied: boolean("applied").default(false),
});

export const thermalSettings = pgTable("thermal_settings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  coolingMode: text("cooling_mode").notNull().default('auto'), // 'auto', 'cool', 'turbo', 'biosmart', 'sunsmart'
  autoOptimization: boolean("auto_optimization").default(true),
  thermalThreshold: real("thermal_threshold").default(65.0),
  emergencyCooling: boolean("emergency_cooling").default(false),
  bioRhythmActive: boolean("bio_rhythm_active").default(false),
  sunSmartActive: boolean("sun_smart_active").default(false),
  predictiveCooling: boolean("predictive_cooling").default(true),
  taskOffloading: boolean("task_offloading").default(true),
  environmentAware: boolean("environment_aware").default(true),
});

// Types
export interface ProcessInfo {
  name: string;
  pid: number;
  cpuUsage: number;
  memoryUsage: number;
  icon?: string;
  category: string;
  thermalImpact?: number;
  priority?: 'low' | 'medium' | 'high' | 'critical';
  canThrottle?: boolean;
}

export interface NetworkInfo {
  type: '5G' | '4G' | 'WiFi';
  downloadSpeed: number;
  uploadSpeed: number;
  signal: number;
  autoSwitch: boolean;
}

export interface SystemData {
  metrics: typeof systemMetrics.$inferSelect;
  networkInfo: NetworkInfo;
  suggestions: typeof optimizationSuggestions.$inferSelect[];
  thermalSettings: typeof thermalSettings.$inferSelect;
}

// Schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertSystemMetricsSchema = createInsertSchema(systemMetrics).omit({
  id: true,
  timestamp: true,
});

export const insertOptimizationSuggestionSchema = createInsertSchema(optimizationSuggestions).omit({
  id: true,
  timestamp: true,
});

export const insertThermalSettingsSchema = createInsertSchema(thermalSettings).omit({
  id: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type SystemMetrics = typeof systemMetrics.$inferSelect;
export type InsertSystemMetrics = z.infer<typeof insertSystemMetricsSchema>;
export type OptimizationSuggestion = typeof optimizationSuggestions.$inferSelect;
export type InsertOptimizationSuggestion = z.infer<typeof insertOptimizationSuggestionSchema>;
export type ThermalSettings = typeof thermalSettings.$inferSelect;
export type InsertThermalSettings = z.infer<typeof insertThermalSettingsSchema>;
