import { useQuery } from '@tanstack/react-query';
import { SystemData } from '@shared/schema';

export function useSystemData() {
  return useQuery<SystemData>({
    queryKey: ['/api/system/current'],
    refetchInterval: 5000, // Refresh every 5 seconds as backup to WebSocket
    staleTime: 1000, // Consider data stale after 1 second
  });
}

export function useSystemHistory(hours: number = 1) {
  return useQuery({
    queryKey: ['/api/system/history', hours],
    refetchInterval: 30000, // Refresh every 30 seconds
  });
}
