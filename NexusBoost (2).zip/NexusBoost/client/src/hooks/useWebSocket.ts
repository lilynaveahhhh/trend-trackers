import { useEffect, useRef, useState } from 'react';
import { SystemData } from '@shared/schema';

interface WebSocketMessage {
  type: string;
  data: any;
}

export function useWebSocket() {
  const [isConnected, setIsConnected] = useState(false);
  const [systemData, setSystemData] = useState<SystemData | null>(null);
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null);
  const wsRef = useRef<WebSocket | null>(null);

  useEffect(() => {
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    
    const connect = () => {
      const socket = new WebSocket(wsUrl);
      wsRef.current = socket;

      socket.onopen = () => {
        console.log('WebSocket connected');
        setIsConnected(true);
      };

      socket.onmessage = (event) => {
        try {
          const message: WebSocketMessage = JSON.parse(event.data);
          handleMessage(message);
        } catch (error) {
          console.error('Error parsing WebSocket message:', error);
        }
      };

      socket.onclose = () => {
        console.log('WebSocket disconnected');
        setIsConnected(false);
        
        // Reconnect after 3 seconds
        setTimeout(connect, 3000);
      };

      socket.onerror = (error) => {
        console.error('WebSocket error:', error);
      };
    };

    connect();

    return () => {
      if (wsRef.current) {
        wsRef.current.close();
      }
    };
  }, []);

  const handleMessage = (message: WebSocketMessage) => {
    switch (message.type) {
      case 'initial':
      case 'systemUpdate':
        setSystemData(message.data);
        setLastUpdate(new Date());
        break;
        
      case 'networkChanged':
        console.log('Network changed:', message.data);
        // Update network info if we have current system data
        if (systemData) {
          setSystemData({
            ...systemData,
            networkInfo: message.data.networkInfo
          });
        }
        break;
        
      case 'optimizationApplied':
        console.log('Optimization applied:', message.data);
        break;
        
      case 'emergencyCooling':
        console.log('Emergency cooling:', message.data);
        break;
        
      case 'thermalSettingsUpdated':
        console.log('Thermal settings updated:', message.data);
        if (systemData) {
          setSystemData({
            ...systemData,
            thermalSettings: message.data
          });
        }
        break;
    }
  };

  const sendMessage = (type: string, payload?: any) => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({ type, payload }));
    }
  };

  const applyOptimization = (suggestionId: string) => {
    sendMessage('optimizationAction', { suggestionId });
  };

  const switchNetwork = (type: '5G' | '4G' | 'WiFi') => {
    sendMessage('networkSwitch', { type });
  };

  const updateThermalSettings = (settings: any) => {
    sendMessage('thermalSettings', settings);
  };

  const activateEmergencyCooling = () => {
    sendMessage('emergencyCooling');
  };

  return {
    isConnected,
    systemData,
    lastUpdate,
    applyOptimization,
    switchNetwork,
    updateThermalSettings,
    activateEmergencyCooling
  };
}
