import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ProcessInfo } from '@shared/schema';
import { Cpu, Zap, X, Thermometer, Activity, Flame, Snowflake } from 'lucide-react';

interface CPUMonitorProps {
  cpuUsage: number;
  processes: ProcessInfo[];
  temperature: number;
  onOptimizeApps: () => void;
  onKillHeavyApps: () => void;
  onThermalThrottle: (processId: number) => void;
}

export function CPUMonitor({ 
  cpuUsage, 
  processes, 
  temperature,
  onOptimizeApps, 
  onKillHeavyApps,
  onThermalThrottle 
}: CPUMonitorProps) {
  const getCpuColor = (usage: number) => {
    if (usage > 80) return 'bg-red-500';
    if (usage > 60) return 'bg-orange-500';
    if (usage > 40) return 'bg-yellow-500';
    return 'bg-green-500';
  };

  const getAppIconColor = (category: string) => {
    switch (category) {
      case 'Development': return 'bg-blue-500';
      case 'Media': return 'bg-green-500';
      case 'Browser': return 'bg-orange-500';
      case 'Gaming': return 'bg-red-500';
      case 'Communication': return 'bg-purple-500';
      case 'Design': return 'bg-pink-500';
      case 'Streaming': return 'bg-indigo-500';
      default: return 'bg-gray-500';
    }
  };

  const getThermalImpactColor = (impact: number) => {
    if (impact > 15) return 'text-red-400 bg-red-500/20';
    if (impact > 10) return 'text-orange-400 bg-orange-500/20';
    if (impact > 5) return 'text-yellow-400 bg-yellow-500/20';
    return 'text-green-400 bg-green-500/20';
  };

  const getPriorityIcon = (priority: string) => {
    switch (priority) {
      case 'critical': return <Flame className="w-3 h-3 text-red-500" />;
      case 'high': return <Activity className="w-3 h-3 text-orange-500" />;
      case 'medium': return <Zap className="w-3 h-3 text-yellow-500" />;
      default: return <Snowflake className="w-3 h-3 text-blue-500" />;
    }
  };

  const getThermalState = (temp: number) => {
    if (temp > 75) return { state: 'CRITICAL', color: 'text-red-400', bg: 'bg-red-500/20' };
    if (temp > 65) return { state: 'HOT', color: 'text-orange-400', bg: 'bg-orange-500/20' };
    if (temp > 55) return { state: 'WARM', color: 'text-yellow-400', bg: 'bg-yellow-500/20' };
    return { state: 'COOL', color: 'text-green-400', bg: 'bg-green-500/20' };
  };

  const thermalState = getThermalState(temperature);

  // Calculate core distribution (simulate 4 cores)
  const coreUsages = [
    Math.random() * 20 + (cpuUsage * 0.6),
    Math.random() * 25 + (cpuUsage * 0.8),
    Math.random() * 15 + (cpuUsage * 0.5),
    Math.random() * 30 + (cpuUsage * 0.9)
  ].map(usage => Math.min(100, Math.max(0, usage)));

  return (
    <Card className="glass-morphism rounded-3xl p-8 thermal-responsive cyber-border">
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-400 to-purple-600 flex items-center justify-center animate-breathing">
            <Cpu className="w-5 h-5 text-white" />
          </div>
          <div>
            <h2 className="text-lg font-bold holographic-text">CPU Intelligence</h2>
            <p className="text-xs text-muted-foreground">Thermal-Aware Processing</p>
          </div>
        </div>
        <div className="text-right space-y-1">
          <div className="flex items-center space-x-2">
            <div className="text-2xl font-bold holographic-text" data-testid="text-cpu-usage">
              {Math.round(cpuUsage)}%
            </div>
            <Badge className={`${thermalState.bg} ${thermalState.color} border-current font-bold text-xs`}>
              {thermalState.state}
            </Badge>
          </div>
          <div className="flex items-center space-x-1 text-xs text-muted-foreground">
            <Thermometer className="w-3 h-3" />
            <span>{Math.round(temperature)}°C</span>
          </div>
        </div>
      </div>

      {/* CPU Cores Visualization */}
      <div className="mb-6">
        <div className="grid grid-cols-4 gap-2 mb-4">
          {coreUsages.map((usage, index) => (
            <div
              key={index}
              className="h-20 bg-gradient-to-t from-primary/20 to-primary rounded-lg flex items-end justify-center pb-2"
              style={{ 
                height: `${Math.max(20, (usage / 100) * 80)}px`,
                background: `linear-gradient(to top, rgba(14, 165, 233, 0.2), rgba(14, 165, 233, ${Math.max(0.3, usage / 100)}))`
              }}
              data-testid={`core-${index + 1}-usage`}
            >
              <span className="text-xs font-mono">{Math.round(usage)}%</span>
            </div>
          ))}
        </div>
        <div className="text-center text-sm text-muted-foreground">Core Distribution</div>
      </div>

      {/* Enhanced App Usage List */}
      <div className="space-y-4 mb-8 max-h-80 overflow-y-auto">
        {processes.slice(0, 6).map((process, index) => (
          <div
            key={process.pid}
            className={`p-4 rounded-xl thermal-responsive transition-all duration-300 ${
              process.thermalImpact && process.thermalImpact > 15 
                ? 'bg-red-500/10 border border-red-500/30' 
                : 'bg-secondary/30 border border-secondary/50'
            }`}
            data-testid={`process-${process.name.toLowerCase().replace(/\s+/g, '-')}`}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className={`w-10 h-10 ${getAppIconColor(process.category)} rounded-xl flex items-center justify-center relative`}>
                  <span className="text-xs font-bold text-white">
                    {process.icon || process.name.substring(0, 2).toUpperCase()}
                  </span>
                  {process.priority && (
                    <div className="absolute -top-1 -right-1">
                      {getPriorityIcon(process.priority)}
                    </div>
                  )}
                </div>
                <div className="flex-1">
                  <div className="flex items-center space-x-2">
                    <div className="font-medium" data-testid={`text-process-name-${index}`}>
                      {process.name}
                    </div>
                    {process.canThrottle && temperature > 65 && (
                      <Badge className="text-xs bg-blue-500/20 text-blue-400 border-blue-500/30">
                        Throttleable
                      </Badge>
                    )}
                  </div>
                  <div className="text-xs text-muted-foreground">{process.category}</div>
                </div>
              </div>
              
              <div className="text-right space-y-1">
                <div className="flex items-center space-x-2">
                  <div className="font-mono text-sm" data-testid={`text-process-cpu-${index}`}>
                    {process.cpuUsage.toFixed(1)}%
                  </div>
                  {process.thermalImpact && (
                    <Badge className={`text-xs ${getThermalImpactColor(process.thermalImpact)}`}>
                      {process.thermalImpact.toFixed(0)}°
                    </Badge>
                  )}
                </div>
                
                <div className="flex items-center space-x-2">
                  <div className="w-16 h-2 bg-secondary rounded-full">
                    <div 
                      className={`h-2 rounded-full ${getCpuColor(process.cpuUsage)}`}
                      style={{ width: `${Math.min(100, process.cpuUsage)}%` }}
                    />
                  </div>
                  
                  {process.canThrottle && temperature > 70 && (
                    <Button
                      size="sm"
                      onClick={() => onThermalThrottle(process.pid)}
                      className="h-6 px-2 text-xs bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-500/40"
                    >
                      <Snowflake className="w-3 h-3" />
                    </Button>
                  )}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-2 gap-3">
        <Button
          onClick={onOptimizeApps}
          className="p-3 bg-primary/20 border border-primary/40 thermal-responsive hover:bg-primary/30"
          data-testid="button-optimize-apps"
        >
          <div className="flex items-center space-x-2">
            <Zap className="w-4 h-4" />
            <span className="text-sm font-medium">Optimize Apps</span>
          </div>
        </Button>
        <Button
          onClick={onKillHeavyApps}
          variant="destructive"
          className="p-3 bg-destructive/20 border border-destructive/40 thermal-responsive hover:bg-destructive/30"
          data-testid="button-kill-heavy-apps"
        >
          <div className="flex items-center space-x-2">
            <X className="w-4 h-4" />
            <span className="text-sm font-medium">Kill Heavy Apps</span>
          </div>
        </Button>
      </div>
    </Card>
  );
}
