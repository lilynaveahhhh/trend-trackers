import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { OptimizationSuggestion } from '@shared/schema';
import { Brain, Lightbulb, Zap, Wifi, Cpu } from 'lucide-react';

interface AIOptimizationProps {
  suggestions: OptimizationSuggestion[];
  autoApply: boolean;
  onApplySuggestion: (suggestionId: string) => void;
  onToggleAutoApply: (enabled: boolean) => void;
}

export function AIOptimization({ 
  suggestions, 
  autoApply, 
  onApplySuggestion, 
  onToggleAutoApply 
}: AIOptimizationProps) {
  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'thermal':
        return <Zap className="w-4 h-4 text-primary" />;
      case 'network':
        return <Wifi className="w-4 h-4 text-blue-400" />;
      case 'process':
        return <Cpu className="w-4 h-4 text-purple-400" />;
      default:
        return <Lightbulb className="w-4 h-4 text-yellow-400" />;
    }
  };

  const getEfficiencyColor = (efficiency: number) => {
    if (efficiency >= 15) return 'text-green-400';
    if (efficiency >= 10) return 'text-blue-400';
    if (efficiency >= 5) return 'text-purple-400';
    return 'text-yellow-400';
  };

  return (
    <Card className="glass-morphism rounded-2xl p-6 thermal-responsive">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold holographic-text">AI Optimization</h2>
        <div className="w-8 h-8 bg-gradient-to-br from-primary to-accent rounded-full animate-heartbeat flex items-center justify-center">
          <Brain className="w-4 h-4 text-white" />
        </div>
      </div>

      {/* AI Status */}
      <div className="mb-6 p-4 bg-gradient-to-r from-primary/20 to-accent/20 rounded-xl border border-primary/30">
        <div className="flex items-center space-x-3 mb-3">
          <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse" />
          <span className="font-medium">Learning Mode Active</span>
        </div>
        <div className="text-sm text-muted-foreground">
          Analyzing usage patterns and thermal behavior
        </div>
      </div>

      {/* Optimization Suggestions */}
      <div className="space-y-3 mb-6 max-h-64 overflow-y-auto">
        {suggestions.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <Brain className="w-12 h-12 mx-auto mb-2 opacity-50" />
            <p>No optimization suggestions at the moment</p>
            <p className="text-xs">System is running optimally</p>
          </div>
        ) : (
          suggestions.map((suggestion) => (
            <div
              key={suggestion.id}
              className="p-3 bg-secondary/30 rounded-xl thermal-responsive"
              data-testid={`suggestion-${suggestion.type}`}
            >
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center space-x-2">
                  {getTypeIcon(suggestion.type)}
                  <span className="text-sm font-medium capitalize">
                    {suggestion.type} Optimization
                  </span>
                </div>
                <span className={`text-xs ${getEfficiencyColor(suggestion.efficiency)}`}>
                  +{suggestion.efficiency}% efficiency
                </span>
              </div>
              <div className="text-xs text-muted-foreground mb-3">
                {suggestion.description}
              </div>
              {!suggestion.applied && (
                <Button
                  onClick={() => onApplySuggestion(suggestion.id)}
                  size="sm"
                  className="w-full bg-primary/20 border border-primary/40 hover:bg-primary/30"
                  data-testid={`button-apply-${suggestion.type}`}
                >
                  Apply Optimization
                </Button>
              )}
              {suggestion.applied && (
                <div className="text-xs text-green-400 font-medium">
                  ✓ Applied
                </div>
              )}
            </div>
          ))
        )}
      </div>

      {/* Auto-Apply Toggle */}
      <div className="p-3 bg-accent/20 rounded-xl border border-accent/40">
        <div className="flex items-center justify-between">
          <span className="text-sm font-medium">Auto-Apply Suggestions</span>
          <Switch
            checked={autoApply}
            onCheckedChange={onToggleAutoApply}
            className="data-[state=checked]:bg-accent"
            data-testid="switch-auto-apply"
          />
        </div>
      </div>
    </Card>
  );
}
