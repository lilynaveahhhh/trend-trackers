import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ThermalSettings } from '@shared/schema';
import { Thermometer, Fan, Snowflake } from 'lucide-react';

interface ThermalControlProps {
  temperature: number;
  thermalSettings: ThermalSettings;
  onModeChange: (mode: string) => void;
  onEmergencyCooling: () => void;
}

export function ThermalControl({ 
  temperature, 
  thermalSettings, 
  onModeChange, 
  onEmergencyCooling 
}: ThermalControlProps) {
  const [isEmergencyActive, setIsEmergencyActive] = useState(false);

  const getTemperatureColor = (temp: number) => {
    if (temp > 70) return 'text-red-500';
    if (temp > 60) return 'text-orange-500';
    if (temp > 50) return 'text-yellow-500';
    return 'text-green-500';
  };

  const getTemperatureRange = (temp: number) => {
    if (temp > 70) return 'Critical';
    if (temp > 60) return 'High';
    if (temp > 50) return 'Warm';
    return 'Optimal';
  };

  const handleEmergencyCooling = () => {
    setIsEmergencyActive(true);
    onEmergencyCooling();
    
    // Auto-disable visual state after 5 seconds
    setTimeout(() => {
      setIsEmergencyActive(false);
    }, 5000);
  };

  return (
    <Card className={`glass-morphism rounded-2xl p-6 thermal-responsive ${
      isEmergencyActive ? 'cooling-active' : ''
    }`}>
      <div className="cooling-overlay rounded-2xl"></div>
      <div className="relative">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold holographic-text">Thermal Control</h2>
          <div className="w-16 h-16 relative">
            {/* Cooling Fan Animation */}
            <div className={`absolute inset-0 ${
              thermalSettings.coolingMode === 'turbo' ? 'animate-spin' : 'animate-cooling-fan'
            }`}>
              <Fan className="w-16 h-16 text-primary" />
            </div>
          </div>
        </div>
        
        {/* Temperature Display */}
        <div className="text-center mb-4">
          <div className={`text-4xl font-bold holographic-text mb-2 ${getTemperatureColor(temperature)}`}>
            {Math.round(temperature)}°C
          </div>
          <div className="w-full bg-secondary rounded-full h-2 mb-2">
            <div 
              className={`h-2 rounded-full animate-pulse-slow ${
                temperature > 70 ? 'bg-gradient-to-r from-red-500 to-orange-500' :
                temperature > 60 ? 'bg-gradient-to-r from-orange-500 to-yellow-500' :
                temperature > 50 ? 'bg-gradient-to-r from-yellow-500 to-green-500' :
                'bg-gradient-to-r from-primary to-accent'
              }`}
              style={{ width: `${Math.min(100, (temperature / 80) * 100)}%` }}
            />
          </div>
          <div className="text-sm text-muted-foreground">
            {getTemperatureRange(temperature)} Range
          </div>
        </div>

        {/* Cooling Modes */}
        <div className="grid grid-cols-2 gap-3 mb-4">
          <Button
            variant={thermalSettings.coolingMode === 'cool' ? 'default' : 'outline'}
            onClick={() => onModeChange('cool')}
            className={`p-3 thermal-responsive ${
              thermalSettings.coolingMode === 'cool' 
                ? 'bg-primary/20 border-primary/40' 
                : 'bg-secondary/50'
            }`}
            data-testid="button-cool-mode"
          >
            <div className="flex items-center space-x-2">
              <Snowflake className="w-4 h-4" />
              <div>
                <div className="text-sm font-medium">Cool Mode</div>
                <div className="text-xs text-muted-foreground">
                  {thermalSettings.coolingMode === 'cool' ? 'Active' : 'Standby'}
                </div>
              </div>
            </div>
          </Button>
          
          <Button
            variant={thermalSettings.coolingMode === 'turbo' ? 'default' : 'outline'}
            onClick={() => onModeChange('turbo')}
            className={`p-3 thermal-responsive ${
              thermalSettings.coolingMode === 'turbo' 
                ? 'bg-primary/20 border-primary/40' 
                : 'bg-secondary/50'
            }`}
            data-testid="button-turbo-mode"
          >
            <div className="flex items-center space-x-2">
              <Fan className="w-4 h-4" />
              <div>
                <div className="text-sm font-medium">Turbo Cool</div>
                <div className="text-xs text-muted-foreground">
                  {thermalSettings.coolingMode === 'turbo' ? 'Active' : 'Standby'}
                </div>
              </div>
            </div>
          </Button>
        </div>

        {/* Emergency Cooling */}
        <Button
          onClick={handleEmergencyCooling}
          disabled={isEmergencyActive}
          className={`w-full p-4 bg-gradient-to-r from-destructive/20 to-orange-500/20 
            border border-destructive/40 thermal-responsive group ${
            isEmergencyActive ? 'animate-pulse' : ''
          }`}
          data-testid="button-emergency-cooling"
        >
          <div className="flex items-center justify-center space-x-2">
            <Thermometer className={`w-5 h-5 text-destructive ${
              isEmergencyActive ? 'animate-bounce' : 'group-hover:animate-spin'
            }`} />
            <span className="font-medium">
              {isEmergencyActive ? 'Emergency Cooling Active' : 'Emergency Cool Down'}
            </span>
          </div>
        </Button>
      </div>
    </Card>
  );
}
