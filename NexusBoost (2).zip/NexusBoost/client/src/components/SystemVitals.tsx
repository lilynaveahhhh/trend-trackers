import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { SystemMetrics } from '@shared/schema';
import { HardDrive, MemoryStick, Zap, Battery, AlertTriangle } from 'lucide-react';

interface SystemVitalsProps {
  metrics: SystemMetrics;
  onEmergencyCooling: () => void;
}

export function SystemVitals({ metrics, onEmergencyCooling }: SystemVitalsProps) {
  const getUsageColor = (percentage: number) => {
    if (percentage > 80) return 'from-red-400 to-red-500';
    if (percentage > 60) return 'from-yellow-400 to-orange-500';
    if (percentage > 40) return 'from-blue-400 to-blue-500';
    return 'from-green-400 to-green-500';
  };

  const memoryPercentage = (metrics.memoryUsage / metrics.memoryTotal) * 100;
  const diskPercentage = (metrics.diskUsage / metrics.diskTotal) * 100;

  return (
    <Card className="glass-morphism rounded-2xl p-6 thermal-responsive">
      <h2 className="text-lg font-semibold holographic-text mb-4">System Vitals</h2>
      
      <div className="space-y-4">
        {/* Memory Usage */}
        <div>
          <div className="flex justify-between text-sm mb-2">
            <div className="flex items-center space-x-2">
              <MemoryStick className="w-4 h-4 text-muted-foreground" />
              <span>Memory</span>
            </div>
            <span className="font-mono" data-testid="text-memory-usage">
              {(metrics.memoryUsage / 1024).toFixed(1)}GB / {metrics.memoryTotal.toFixed(1)}GB
            </span>
          </div>
          <div className="w-full bg-secondary rounded-full h-3">
            <div 
              className={`bg-gradient-to-r ${getUsageColor(memoryPercentage)} h-3 rounded-full animate-pulse-slow`}
              style={{ width: `${memoryPercentage}%` }}
            />
          </div>
        </div>

        {/* Disk Usage */}
        <div>
          <div className="flex justify-between text-sm mb-2">
            <div className="flex items-center space-x-2">
              <HardDrive className="w-4 h-4 text-muted-foreground" />
              <span>Storage</span>
            </div>
            <span className="font-mono" data-testid="text-disk-usage">
              {Math.round(metrics.diskUsage)}GB / {Math.round(metrics.diskTotal)}GB
            </span>
          </div>
          <div className="w-full bg-secondary rounded-full h-3">
            <div 
              className={`bg-gradient-to-r ${getUsageColor(diskPercentage)} h-3 rounded-full`}
              style={{ width: `${diskPercentage}%` }}
            />
          </div>
        </div>

        {/* GPU Usage */}
        <div>
          <div className="flex justify-between text-sm mb-2">
            <div className="flex items-center space-x-2">
              <Zap className="w-4 h-4 text-muted-foreground" />
              <span>GPU</span>
            </div>
            <span className="font-mono" data-testid="text-gpu-usage">
              {Math.round(metrics.gpuUsage)}%
            </span>
          </div>
          <div className="w-full bg-secondary rounded-full h-3">
            <div 
              className={`bg-gradient-to-r ${getUsageColor(metrics.gpuUsage)} h-3 rounded-full animate-pulse-slow`}
              style={{ width: `${metrics.gpuUsage}%` }}
            />
          </div>
        </div>

        {/* Battery */}
        <div>
          <div className="flex justify-between text-sm mb-2">
            <div className="flex items-center space-x-2">
              <Battery className="w-4 h-4 text-muted-foreground" />
              <span>Battery</span>
            </div>
            <span className="font-mono" data-testid="text-battery-level">
              {Math.round(metrics.batteryLevel)}%
            </span>
          </div>
          <div className="w-full bg-secondary rounded-full h-3">
            <div 
              className={`bg-gradient-to-r ${
                metrics.batteryLevel > 50 ? 'from-green-500 to-green-400' :
                metrics.batteryLevel > 20 ? 'from-yellow-500 to-orange-400' :
                'from-red-500 to-red-400'
              } h-3 rounded-full`}
              style={{ width: `${metrics.batteryLevel}%` }}
            />
          </div>
        </div>
      </div>

      {/* Emergency Cooling */}
      <Button
        onClick={onEmergencyCooling}
        className="w-full mt-6 p-4 bg-gradient-to-r from-destructive/20 to-orange-500/20 
          border border-destructive/40 thermal-responsive group hover:bg-destructive/30"
        data-testid="button-emergency-cooling"
      >
        <div className="flex items-center justify-center space-x-2">
          <AlertTriangle className="w-5 h-5 text-destructive group-hover:animate-bounce" />
          <span className="font-medium">Emergency Cool Down</span>
        </div>
      </Button>
    </Card>
  );
}
