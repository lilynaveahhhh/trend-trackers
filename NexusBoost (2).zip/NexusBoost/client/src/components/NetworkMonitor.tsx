import { Card } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Wifi, Signal, Zap } from 'lucide-react';
import { NetworkInfo } from '@shared/schema';

interface NetworkMonitorProps {
  networkInfo: NetworkInfo;
  onNetworkSwitch: (type: '5G' | '4G' | 'WiFi') => void;
  onAutoSwitchToggle: (enabled: boolean) => void;
}

export function NetworkMonitor({ 
  networkInfo, 
  onNetworkSwitch, 
  onAutoSwitchToggle 
}: NetworkMonitorProps) {
  const getSignalStrength = (signal: number) => {
    if (signal >= 80) return 'excellent';
    if (signal >= 60) return 'good';
    if (signal >= 40) return 'fair';
    return 'poor';
  };

  const getNetworkIcon = (type: string) => {
    switch (type) {
      case '5G':
        return <Zap className="w-4 h-4" />;
      case '4G':
        return <Signal className="w-4 h-4" />;
      default:
        return <Wifi className="w-4 h-4" />;
    }
  };

  return (
    <Card className="glass-morphism rounded-2xl p-6 thermal-responsive">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold holographic-text">Network Intelligence</h2>
        <div className="flex items-center space-x-2">
          <div 
            className={`w-2 h-2 rounded-full animate-pulse ${
              getSignalStrength(networkInfo.signal) === 'excellent' ? 'bg-green-500' :
              getSignalStrength(networkInfo.signal) === 'good' ? 'bg-blue-500' :
              getSignalStrength(networkInfo.signal) === 'fair' ? 'bg-yellow-500' : 'bg-red-500'
            }`}
          />
          <div className="flex items-center space-x-1">
            {getNetworkIcon(networkInfo.type)}
            <span className="text-sm font-mono text-green-400">
              {networkInfo.type}
            </span>
          </div>
        </div>
      </div>
      
      <div className="space-y-4">
        {/* Auto-Switch Toggle */}
        <div className="flex justify-between items-center p-3 bg-secondary/50 rounded-xl">
          <span className="text-sm">Auto-Switch Mode</span>
          <Switch
            checked={networkInfo.autoSwitch}
            onCheckedChange={onAutoSwitchToggle}
            className="data-[state=checked]:bg-primary"
          />
        </div>
        
        {/* Network Stats */}
        <div className="grid grid-cols-2 gap-4">
          <div className="text-center p-3 bg-secondary/30 rounded-xl">
            <div className="text-2xl font-bold holographic-text">
              {Math.round(networkInfo.downloadSpeed)}
            </div>
            <div className="text-xs text-muted-foreground">Mbps Down</div>
          </div>
          <div className="text-center p-3 bg-secondary/30 rounded-xl">
            <div className="text-2xl font-bold holographic-text">
              {Math.round(networkInfo.uploadSpeed)}
            </div>
            <div className="text-xs text-muted-foreground">Mbps Up</div>
          </div>
        </div>

        {/* Network Type Buttons */}
        <div className="grid grid-cols-3 gap-2">
          {(['5G', '4G', 'WiFi'] as const).map((type) => (
            <button
              key={type}
              onClick={() => onNetworkSwitch(type)}
              className={`p-2 rounded-lg text-sm font-medium thermal-responsive transition-all ${
                networkInfo.type === type
                  ? 'bg-primary/30 border border-primary/50 text-primary'
                  : 'bg-secondary/30 border border-secondary/50 hover:bg-secondary/50'
              }`}
              data-testid={`button-switch-${type.toLowerCase()}`}
            >
              {type}
            </button>
          ))}
        </div>

        {/* Smart Switching Info */}
        <div className="p-4 bg-gradient-to-r from-primary/20 to-accent/20 rounded-xl border border-primary/30">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 rounded-full bg-primary/30 flex items-center justify-center">
              <Zap className="w-4 h-4 text-primary" />
            </div>
            <div>
              <div className="font-medium">AI Network Optimization</div>
              <div className="text-xs text-muted-foreground">
                Thermal-aware switching active
              </div>
            </div>
          </div>
        </div>
      </div>
    </Card>
  );
}
