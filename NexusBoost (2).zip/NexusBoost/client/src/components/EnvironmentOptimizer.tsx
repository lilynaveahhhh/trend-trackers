import React, { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { 
  MapPin, 
  Thermometer, 
  CloudRain, 
  Wind, 
  Sun, 
  Moon,
  Zap,
  Wifi,
  Battery,
  Globe
} from 'lucide-react';

interface EnvironmentOptimizerProps {
  onOptimizationToggle: (feature: string, enabled: boolean) => void;
}

export function EnvironmentOptimizer({ onOptimizationToggle }: EnvironmentOptimizerProps) {
  const [location, setLocation] = useState({ city: 'San Francisco', temp: 22, weather: 'sunny' });
  const [environmentMode, setEnvironmentMode] = useState(true);
  const [taskOffloading, setTaskOffloading] = useState(true);
  const [weatherData, setWeatherData] = useState({
    temperature: 22,
    humidity: 65,
    windSpeed: 12,
    condition: 'sunny'
  });

  // Simulate location and weather data
  useEffect(() => {
    const updateEnvironment = () => {
      const cities = [
        { city: 'San Francisco', temp: 18, weather: 'cloudy' },
        { city: 'Miami', temp: 32, weather: 'sunny' },
        { city: 'Seattle', temp: 15, weather: 'rainy' },
        { city: 'Phoenix', temp: 38, weather: 'sunny' },
        { city: 'Denver', temp: 25, weather: 'clear' }
      ];
      
      const randomCity = cities[Math.floor(Math.random() * cities.length)];
      setLocation(randomCity);
      
      setWeatherData({
        temperature: randomCity.temp + Math.random() * 6 - 3,
        humidity: Math.random() * 40 + 40,
        windSpeed: Math.random() * 20 + 5,
        condition: randomCity.weather
      });
    };

    const interval = setInterval(updateEnvironment, 8000);
    updateEnvironment();
    
    return () => clearInterval(interval);
  }, []);

  const getWeatherIcon = (condition: string) => {
    switch (condition) {
      case 'sunny': return <Sun className="w-5 h-5 text-yellow-400" />;
      case 'cloudy': return <Wind className="w-5 h-5 text-gray-400" />;
      case 'rainy': return <CloudRain className="w-5 h-5 text-blue-400" />;
      default: return <Sun className="w-5 h-5 text-yellow-400" />;
    }
  };

  const getThermalRisk = (temp: number) => {
    if (temp > 35) return { level: 'EXTREME', color: 'bg-red-500', text: 'text-red-400' };
    if (temp > 28) return { level: 'HIGH', color: 'bg-orange-500', text: 'text-orange-400' };
    if (temp > 20) return { level: 'MODERATE', color: 'bg-yellow-500', text: 'text-yellow-400' };
    return { level: 'LOW', color: 'bg-green-500', text: 'text-green-400' };
  };

  const thermalRisk = getThermalRisk(weatherData.temperature);

  const handleEnvironmentToggle = (enabled: boolean) => {
    setEnvironmentMode(enabled);
    onOptimizationToggle('environment', enabled);
  };

  const handleTaskOffloadingToggle = (enabled: boolean) => {
    setTaskOffloading(enabled);
    onOptimizationToggle('taskOffloading', enabled);
  };

  return (
    <Card className="glass-morphism rounded-3xl p-6 frost-effect relative overflow-hidden">
      {/* Animated Weather Background */}
      <div className={`absolute inset-0 opacity-20 ${
        weatherData.condition === 'sunny' ? 'bg-gradient-to-br from-yellow-400/30 to-orange-500/20' :
        weatherData.condition === 'rainy' ? 'bg-gradient-to-br from-blue-400/30 to-indigo-500/20' :
        'bg-gradient-to-br from-gray-400/30 to-slate-500/20'
      } transition-all duration-1000`} />

      <div className="relative z-10">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-green-400 to-blue-600 flex items-center justify-center animate-breathing">
              <Globe className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-lg font-bold holographic-text">Environment AI</h2>
              <p className="text-xs text-muted-foreground">Location-Based Optimization</p>
            </div>
          </div>
          
          <Badge className={`${thermalRisk.color} text-white font-bold animate-pulse`}>
            {thermalRisk.level} RISK
          </Badge>
        </div>

        {/* Location & Weather */}
        <div className="mb-6 p-4 bg-gradient-to-r from-secondary/50 to-secondary/30 rounded-2xl border border-secondary/50">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center space-x-2">
              <MapPin className="w-4 h-4 text-primary" />
              <span className="font-medium">{location.city}</span>
            </div>
            {getWeatherIcon(weatherData.condition)}
          </div>
          
          <div className="grid grid-cols-3 gap-3 text-sm">
            <div className="text-center">
              <Thermometer className={`w-4 h-4 mx-auto mb-1 ${thermalRisk.text}`} />
              <div className="font-mono text-xs">{Math.round(weatherData.temperature)}°C</div>
            </div>
            <div className="text-center">
              <Wind className="w-4 h-4 mx-auto mb-1 text-blue-400" />
              <div className="font-mono text-xs">{Math.round(weatherData.windSpeed)} km/h</div>
            </div>
            <div className="text-center">
              <CloudRain className="w-4 h-4 mx-auto mb-1 text-cyan-400" />
              <div className="font-mono text-xs">{Math.round(weatherData.humidity)}%</div>
            </div>
          </div>
        </div>

        {/* Environment-Aware Mode */}
        <div className={`mb-6 p-4 rounded-2xl border transition-all duration-500 ${
          environmentMode 
            ? 'bg-gradient-to-r from-green-500/20 to-blue-500/20 border-green-500/50' 
            : 'bg-secondary/30 border-secondary/50'
        }`}>
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-2">
              <Globe className={`w-5 h-5 ${environmentMode ? 'text-green-400 animate-breathing' : 'text-muted-foreground'}`} />
              <span className="font-medium">Auto Environment Mode</span>
            </div>
            <Switch
              checked={environmentMode}
              onCheckedChange={handleEnvironmentToggle}
              className="data-[state=checked]:bg-green-500"
              data-testid="switch-environment-mode"
            />
          </div>
          
          {environmentMode && weatherData.temperature > 30 && (
            <div className="text-sm bg-orange-500/10 border border-orange-500/30 rounded-lg p-3">
              <div className="flex items-center space-x-2 text-orange-400 mb-2">
                <Sun className="w-4 h-4" />
                <span className="font-medium">Extreme Heat Detected</span>
              </div>
              <div className="text-xs space-y-1">
                <div>🌡️ Enabling thermal protection mode</div>
                <div>⚡ Reducing CPU/GPU power limits</div>
                <div>📶 Switching to power-efficient networks</div>
              </div>
            </div>
          )}
        </div>

        {/* Task Offloading System */}
        <div className={`mb-6 p-4 rounded-2xl border transition-all duration-500 ${
          taskOffloading 
            ? 'bg-gradient-to-r from-purple-500/20 to-cyan-500/20 border-purple-500/50' 
            : 'bg-secondary/30 border-secondary/50'
        }`}>
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-2">
              <Zap className={`w-5 h-5 ${taskOffloading ? 'text-purple-400' : 'text-muted-foreground'}`} />
              <span className="font-medium">Smart Task Offloading</span>
            </div>
            <Switch
              checked={taskOffloading}
              onCheckedChange={handleTaskOffloadingToggle}
              className="data-[state=checked]:bg-purple-500"
              data-testid="switch-task-offloading"
            />
          </div>
          
          {taskOffloading && (
            <div className="space-y-3">
              <div className="text-xs text-purple-400 font-medium mb-2">Component Temperature Distribution:</div>
              
              <div className="grid grid-cols-3 gap-2">
                <div className="bg-secondary/50 rounded-lg p-2 text-center">
                  <div className="text-xs font-mono text-blue-400">CPU</div>
                  <div className="text-sm font-bold">65°C</div>
                  <div className="w-full h-1 bg-blue-500/30 rounded-full">
                    <div className="w-3/4 h-1 bg-blue-500 rounded-full" />
                  </div>
                </div>
                
                <div className="bg-secondary/50 rounded-lg p-2 text-center">
                  <div className="text-xs font-mono text-green-400">GPU</div>
                  <div className="text-sm font-bold">72°C</div>
                  <div className="w-full h-1 bg-green-500/30 rounded-full">
                    <div className="w-4/5 h-1 bg-green-500 rounded-full" />
                  </div>
                </div>
                
                <div className="bg-secondary/50 rounded-lg p-2 text-center">
                  <div className="text-xs font-mono text-yellow-400">NPU</div>
                  <div className="text-sm font-bold">58°C</div>
                  <div className="w-full h-1 bg-yellow-500/30 rounded-full">
                    <div className="w-1/2 h-1 bg-yellow-500 rounded-full" />
                  </div>
                </div>
              </div>
              
              <div className="text-xs text-purple-400 bg-purple-500/10 p-2 rounded-lg">
                🔄 Redistributing AI workload to cooler NPU • GPU throttling to 80%
              </div>
            </div>
          )}
        </div>

        {/* Quick Environment Actions */}
        <div className="grid grid-cols-2 gap-3">
          <Button 
            variant="outline" 
            className="p-3 bg-secondary/50 hover:bg-blue-500/20 border-blue-500/30 thermal-responsive"
            data-testid="button-cooling-mode"
          >
            <div className="flex items-center space-x-2">
              <Wind className="w-4 h-4" />
              <span className="text-sm">Cooling Mode</span>
            </div>
          </Button>
          
          <Button 
            variant="outline" 
            className="p-3 bg-secondary/50 hover:bg-green-500/20 border-green-500/30 thermal-responsive"
            data-testid="button-eco-mode"
          >
            <div className="flex items-center space-x-2">
              <Battery className="w-4 h-4" />
              <span className="text-sm">Eco Mode</span>
            </div>
          </Button>
        </div>
      </div>
    </Card>
  );
}