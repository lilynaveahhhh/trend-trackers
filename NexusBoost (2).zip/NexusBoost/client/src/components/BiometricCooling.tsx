import React, { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Progress } from '@/components/ui/progress';
import { 
  Heart, 
  Sun, 
  Brain, 
  Waves, 
  Zap, 
  Eye,
  Wind,
  Thermometer,
  Battery,
  Cpu
} from 'lucide-react';

interface BiometricCoolingProps {
  temperature: number;
  onModeToggle: (mode: string, enabled: boolean) => void;
}

export function BiometricCooling({ temperature, onModeToggle }: BiometricCoolingProps) {
  const [bioRhythmActive, setBioRhythmActive] = useState(false);
  const [sunSmartActive, setSunSmartActive] = useState(false);
  const [predictiveMode, setPredictiveMode] = useState(true);
  const [breathingRate, setBreathingRate] = useState(0);
  const [heartbeatPhase, setHeartbeatPhase] = useState(0);
  const [sunlightDetected, setSunlightDetected] = useState(false);
  const [heatPrediction, setHeatPrediction] = useState(0);

  // Simulate bio-rhythm data
  useEffect(() => {
    const interval = setInterval(() => {
      setBreathingRate(Math.sin(Date.now() / 3000) * 30 + 70);
      setHeartbeatPhase((prev) => (prev + 1) % 100);
      setSunlightDetected(Math.random() > 0.7);
      setHeatPrediction(Math.random() * 100);
    }, 500);

    return () => clearInterval(interval);
  }, []);

  const handleBioRhythmToggle = (enabled: boolean) => {
    setBioRhythmActive(enabled);
    onModeToggle('bioRhythm', enabled);
  };

  const handleSunSmartToggle = (enabled: boolean) => {
    setSunSmartActive(enabled);
    onModeToggle('sunSmart', enabled);
  };

  const getThermalZone = (temp: number) => {
    if (temp > 75) return { zone: 'CRITICAL', color: 'bg-red-500', glow: 'shadow-red-500/50' };
    if (temp > 65) return { zone: 'HOT', color: 'bg-orange-500', glow: 'shadow-orange-500/50' };
    if (temp > 55) return { zone: 'WARM', color: 'bg-yellow-500', glow: 'shadow-yellow-500/50' };
    return { zone: 'OPTIMAL', color: 'bg-green-500', glow: 'shadow-green-500/50' };
  };

  const thermalZone = getThermalZone(temperature);

  return (
    <Card className="glass-morphism rounded-3xl p-8 cyber-border relative overflow-hidden">
      {/* Animated background */}
      <div className="absolute inset-0 opacity-10">
        <div className="animate-neural-flow w-full h-full bg-gradient-to-br from-cyan-500/20 via-purple-500/20 to-pink-500/20" />
      </div>

      <div className="relative z-10">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-400 to-purple-600 flex items-center justify-center animate-bio-heartbeat">
              <Brain className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-lg font-bold holographic-text">BRAC System</h2>
              <p className="text-xs text-muted-foreground">Bio-Rhythm Adaptive Cooling</p>
            </div>
          </div>
          
          {/* Thermal Status */}
          <div className={`px-3 py-1 rounded-full text-xs font-bold ${thermalZone.color} ${thermalZone.glow} animate-pulse`}>
            {thermalZone.zone}
          </div>
        </div>

        {/* Bio-Rhythm Section */}
        <div className={`mb-8 p-6 rounded-2xl border transition-all duration-500 ${
          bioRhythmActive 
            ? 'bg-gradient-to-r from-cyan-500/20 to-purple-500/20 border-cyan-500/50 bio-rhythm' 
            : 'bg-secondary/30 border-secondary/50'
        }`}>
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-2">
              <Heart className={`w-5 h-5 ${bioRhythmActive ? 'text-cyan-400 animate-heartbeat' : 'text-muted-foreground'}`} />
              <span className="font-medium">Bio-Rhythm Cooling</span>
            </div>
            <Switch
              checked={bioRhythmActive}
              onCheckedChange={handleBioRhythmToggle}
              className="data-[state=checked]:bg-cyan-500"
              data-testid="switch-bio-rhythm"
            />
          </div>
          
          {bioRhythmActive && (
            <div className="space-y-3">
              {/* Digital Sweating */}
              <div className="flex items-center justify-between">
                <span className="text-sm flex items-center space-x-2">
                  <Waves className="w-4 h-4 text-cyan-400" />
                  <span>Digital Sweating</span>
                </span>
                <Progress value={breathingRate} className="w-20 h-2" />
              </div>
              
              {/* Heartbeat Rhythm */}
              <div className="flex items-center justify-between">
                <span className="text-sm flex items-center space-x-2">
                  <Heart className="w-4 h-4 text-pink-400 animate-heartbeat" />
                  <span>Heartbeat Throttling</span>
                </span>
                <div className="w-20 h-2 bg-secondary rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-gradient-to-r from-pink-500 to-red-500 transition-all duration-300"
                    style={{ width: `${heartbeatPhase}%` }}
                  />
                </div>
              </div>
              
              {/* Rest Reflex */}
              <div className="text-xs text-cyan-400 font-mono">
                ⚡ Micro-pauses: {Math.floor(breathingRate / 10)}/min
              </div>
            </div>
          )}
        </div>

        {/* SunSmart AI Section */}
        <div className={`mb-6 p-4 rounded-2xl border transition-all duration-500 ${
          sunSmartActive 
            ? 'bg-gradient-to-r from-yellow-500/20 to-orange-500/20 border-yellow-500/50 sunsmart-active' 
            : 'bg-secondary/30 border-secondary/50'
        }`}>
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-2">
              <Sun className={`w-5 h-5 ${sunSmartActive ? 'text-yellow-400 animate-sun-pulse' : 'text-muted-foreground'}`} />
              <span className="font-medium">SunSmart AI</span>
            </div>
            <Switch
              checked={sunSmartActive}
              onCheckedChange={handleSunSmartToggle}
              className="data-[state=checked]:bg-yellow-500"
              data-testid="switch-sunsmart"
            />
          </div>
          
          {sunSmartActive && (
            <div className="space-y-3">
              {/* Light Sensor */}
              <div className="flex items-center justify-between">
                <span className="text-sm flex items-center space-x-2">
                  <Eye className="w-4 h-4 text-yellow-400" />
                  <span>Light Detection</span>
                </span>
                <div className={`w-3 h-3 rounded-full ${sunlightDetected ? 'bg-yellow-500 animate-pulse' : 'bg-gray-500'}`} />
              </div>
              
              {/* GPS + AI Prediction */}
              <div className="flex items-center justify-between">
                <span className="text-sm">Heat Prediction</span>
                <span className="text-xs font-mono text-yellow-400">
                  {heatPrediction.toFixed(0)}% risk
                </span>
              </div>
              
              {sunlightDetected && (
                <div className="text-xs text-yellow-400 font-mono bg-yellow-500/10 p-2 rounded-lg">
                  ☀️ Direct sunlight detected - Preemptive cooling active
                </div>
              )}
            </div>
          )}
        </div>

        {/* Predictive Heat AI */}
        <div className={`p-4 rounded-2xl border bg-secondary/30 border-secondary/50 predictive-glow ${
          predictiveMode ? 'border-purple-500/50' : ''
        }`}>
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-2">
              <Zap className="w-5 h-5 text-purple-400" />
              <span className="font-medium">Predictive Heat AI</span>
            </div>
            <Switch
              checked={predictiveMode}
              onCheckedChange={setPredictiveMode}
              className="data-[state=checked]:bg-purple-500"
              data-testid="switch-predictive"
            />
          </div>
          
          {predictiveMode && (
            <div className="space-y-3">
              <div className="grid grid-cols-3 gap-2 text-xs">
                <div className="text-center p-2 bg-secondary/50 rounded-lg">
                  <Cpu className="w-4 h-4 mx-auto mb-1 text-blue-400" />
                  <div className="font-mono">CPU</div>
                  <div className="text-blue-400">{Math.floor(temperature * 0.8)}°C</div>
                </div>
                <div className="text-center p-2 bg-secondary/50 rounded-lg">
                  <Zap className="w-4 h-4 mx-auto mb-1 text-green-400" />
                  <div className="font-mono">GPU</div>
                  <div className="text-green-400">{Math.floor(temperature * 0.9)}°C</div>
                </div>
                <div className="text-center p-2 bg-secondary/50 rounded-lg">
                  <Battery className="w-4 h-4 mx-auto mb-1 text-yellow-400" />
                  <div className="font-mono">NPU</div>
                  <div className="text-yellow-400">{Math.floor(temperature * 0.7)}°C</div>
                </div>
              </div>
              
              <div className="text-xs font-mono text-purple-400 bg-purple-500/10 p-2 rounded-lg">
                🧠 Learning patterns: Gaming at {new Date().getHours()}h, Outdoor usage detected
              </div>
            </div>
          )}
        </div>

        {/* Virtual Cooling Fan Effect */}
        <div className="mt-6 flex justify-center">
          <Button 
            className="relative group bg-gradient-to-r from-cyan-500 to-purple-600 hover:from-cyan-400 hover:to-purple-500 px-8 py-3 rounded-2xl font-bold text-white shadow-lg hover:shadow-cyan-500/25 transition-all duration-300"
            data-testid="button-activate-brac"
          >
            <div className="flex items-center space-x-2">
              <Wind className="w-5 h-5 group-hover:animate-cooling-fan" />
              <span>Activate BRAC Mode</span>
            </div>
            <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-cyan-500/20 to-purple-600/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
          </Button>
        </div>
      </div>
    </Card>
  );
}