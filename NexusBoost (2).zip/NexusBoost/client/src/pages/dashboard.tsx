import { useWebSocket } from '@/hooks/useWebSocket';
import { useToast } from '@/hooks/use-toast';
import { ParticleBackground } from '@/components/ParticleBackground';
import { NetworkMonitor } from '@/components/NetworkMonitor';
import { ThermalControl } from '@/components/ThermalControl';
import { CPUMonitor } from '@/components/CPUMonitor';
import { AIOptimization } from '@/components/AIOptimization';
import { SystemVitals } from '@/components/SystemVitals';
import { BiometricCooling } from '@/components/BiometricCooling';
import { EnvironmentOptimizer } from '@/components/EnvironmentOptimizer';
import { Card } from '@/components/ui/card';
import { Zap, Wifi, Activity, Brain, Cpu } from 'lucide-react';

export default function Dashboard() {
  const {
    isConnected,
    systemData,
    lastUpdate,
    applyOptimization,
    switchNetwork,
    updateThermalSettings,
    activateEmergencyCooling
  } = useWebSocket();
  
  const { toast } = useToast();

  const handleNetworkSwitch = (type: '5G' | '4G' | 'WiFi') => {
    switchNetwork(type);
    toast({
      title: "Network Switch",
      description: `Switching to ${type}...`,
    });
  };

  const handleThermalModeChange = (mode: string) => {
    updateThermalSettings({ coolingMode: mode });
    toast({
      title: "Cooling Mode",
      description: `Switched to ${mode} mode`,
    });
  };

  const handleEmergencyCooling = () => {
    activateEmergencyCooling();
    toast({
      title: "Emergency Cooling",
      description: "Emergency cooling protocols activated",
      variant: "destructive",
    });
  };

  const handleOptimizeApps = () => {
    toast({
      title: "App Optimization",
      description: "Optimizing application performance...",
    });
  };

  const handleKillHeavyApps = () => {
    toast({
      title: "Process Management",
      description: "Terminating high-resource applications...",
      variant: "destructive",
    });
  };

  const handleThermalThrottle = (processId: number) => {
    toast({
      title: "Thermal Throttling",
      description: `Reducing power for process ${processId}...`,
    });
  };

  const handleBiometricToggle = (mode: string, enabled: boolean) => {
    toast({
      title: "Biometric Cooling",
      description: `${mode} mode ${enabled ? 'activated' : 'deactivated'}`,
    });
  };

  const handleEnvironmentToggle = (feature: string, enabled: boolean) => {
    toast({
      title: "Environment AI",
      description: `${feature} optimization ${enabled ? 'enabled' : 'disabled'}`,
    });
  };

  const handleApplySuggestion = (suggestionId: string) => {
    applyOptimization(suggestionId);
    toast({
      title: "Optimization Applied",
      description: "AI optimization has been applied successfully",
    });
  };

  const handleAutoApplyToggle = (enabled: boolean) => {
    updateThermalSettings({ autoOptimization: enabled });
    toast({
      title: "Auto-Apply Settings",
      description: `Auto-apply ${enabled ? 'enabled' : 'disabled'}`,
    });
  };

  const handleNetworkAutoToggle = (enabled: boolean) => {
    // This would be handled by the network manager
    toast({
      title: "Auto-Switch Network",
      description: `Network auto-switching ${enabled ? 'enabled' : 'disabled'}`,
    });
  };

  if (!systemData) {
    return (
      <div className="min-h-screen bg-background text-foreground flex items-center justify-center neural-grid">
        <ParticleBackground />
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <h2 className="text-xl font-semibold holographic-text mb-2">Initializing ThermalFlow AI</h2>
          <p className="text-muted-foreground">
            {isConnected ? 'Loading system data...' : 'Connecting to system monitor...'}
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground overflow-hidden neural-grid">
      <ParticleBackground />
      
      {/* Main Container */}
      <div className="relative min-h-screen p-8">
        {/* Enhanced Header */}
        <Card className="glass-morphism rounded-3xl p-8 mb-10 thermal-responsive cyber-border">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="relative">
                <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-cyan-400 via-purple-500 to-pink-500 flex items-center justify-center animate-breathing">
                  <Brain className="w-7 h-7 text-white" />
                </div>
                <div className="absolute -top-1 -right-1 w-4 h-4 bg-green-500 rounded-full animate-heartbeat" />
              </div>
              <div>
                <h1 className="text-3xl font-bold holographic-text">NeuralFlow AI</h1>
                <p className="text-sm text-muted-foreground flex items-center space-x-2">
                  <Cpu className="w-4 h-4" />
                  <span>Bio-Rhythm Adaptive Cooling • SunSmart AI • Predictive Thermal Management</span>
                </p>
              </div>
            </div>
            
            {/* Global Status */}
            <div className="flex items-center space-x-6">
              <div className="text-right">
                <div className="text-sm font-medium holographic-text">System Health</div>
                <div className="text-xs text-muted-foreground">
                  {systemData.metrics.temperature > 70 ? 'Thermal Warning' :
                   systemData.metrics.temperature > 60 ? 'Running Warm' :
                   'Optimal Performance'}
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <div className={`w-3 h-3 rounded-full animate-heartbeat ${
                  isConnected ? 'bg-green-500' : 'bg-red-500'
                }`} />
                <Activity className="w-4 h-4 text-muted-foreground" />
              </div>
            </div>
          </div>
        </Card>

        {/* Spacious Main Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-8">
          {/* Left Column - Network & CPU */}
          <div className="space-y-8">
            <NetworkMonitor
              networkInfo={systemData.networkInfo}
              onNetworkSwitch={handleNetworkSwitch}
              onAutoSwitchToggle={handleNetworkAutoToggle}
            />
            
            <CPUMonitor
              cpuUsage={systemData.metrics.cpuUsage}
              processes={systemData.metrics.processes}
              temperature={systemData.metrics.temperature}
              onOptimizeApps={handleOptimizeApps}
              onKillHeavyApps={handleKillHeavyApps}
              onThermalThrottle={handleThermalThrottle}
            />
          </div>

          {/* Center Column - Biometric & Thermal */}
          <div className="space-y-8">
            <BiometricCooling
              temperature={systemData.metrics.temperature}
              onModeToggle={handleBiometricToggle}
            />
            
            <ThermalControl
              temperature={systemData.metrics.temperature}
              thermalSettings={systemData.thermalSettings}
              onModeChange={handleThermalModeChange}
              onEmergencyCooling={handleEmergencyCooling}
            />
          </div>

          {/* Right Column - AI & Environment */}
          <div className="space-y-8">
            <AIOptimization
              suggestions={systemData.suggestions}
              autoApply={systemData.thermalSettings.autoOptimization || false}
              onApplySuggestion={handleApplySuggestion}
              onToggleAutoApply={handleAutoApplyToggle}
            />
            
            <div className="grid grid-cols-1 gap-8">
              <EnvironmentOptimizer
                onOptimizationToggle={handleEnvironmentToggle}
              />
              
              <SystemVitals
                metrics={systemData.metrics}
                onEmergencyCooling={handleEmergencyCooling}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Connection Status */}
      {!isConnected && (
        <div className="fixed bottom-4 right-4 glass-morphism rounded-xl p-4 border border-destructive/40">
          <div className="flex items-center space-x-2">
            <Wifi className="w-4 h-4 text-destructive" />
            <span className="text-sm">Connection Lost - Reconnecting...</span>
          </div>
        </div>
      )}

      {/* Last Update Indicator */}
      {lastUpdate && (
        <div className="fixed bottom-4 left-4 glass-morphism rounded-xl p-2 px-4">
          <div className="text-xs text-muted-foreground">
            Last update: {lastUpdate.toLocaleTimeString()}
          </div>
        </div>
      )}
    </div>
  );
}
