# System Monitor & AI Optimization Platform

## Overview

This is a real-time system monitoring and AI-powered optimization platform built with a modern full-stack architecture. The application provides live monitoring of system metrics (CPU, memory, temperature, network) with intelligent optimization suggestions and automated resource management. It features a sophisticated dashboard with WebSocket-powered real-time updates, thermal management controls, network switching capabilities, and an AI optimization engine that learns from system behavior patterns.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **React + TypeScript with Vite**: Modern single-page application using React 18 with TypeScript for type safety and Vite for fast development and optimized builds
- **Component-Based Design**: Modular UI components using shadcn/ui library built on Radix UI primitives for accessibility and consistency
- **Real-time Data Management**: TanStack Query for server state management with WebSocket integration for live system metrics updates
- **Styling System**: Tailwind CSS with custom CSS variables for theming, including specialized animations for thermal states and particle effects
- **Routing**: Wouter for lightweight client-side routing

### Backend Architecture
- **Express.js REST API**: RESTful server with middleware for logging, error handling, and JSON parsing
- **WebSocket Server**: Real-time bidirectional communication for live system updates and control actions
- **Service-Oriented Architecture**: Modular services including SystemMonitor, AIOptimizer, and NetworkManager for separation of concerns
- **TypeScript Throughout**: Full-stack type safety with shared schema definitions between frontend and backend

### Data Storage Solutions
- **Drizzle ORM**: Type-safe database toolkit configured for PostgreSQL with schema-first design
- **Shared Schema**: Centralized database schema definitions in shared directory ensuring consistency across frontend and backend
- **In-Memory Storage**: Current implementation uses memory storage with interface-based abstraction for easy database migration
- **Migration System**: Database versioning through Drizzle Kit for schema evolution

### Real-time System Monitoring
- **Live Metrics Collection**: Automated collection of CPU usage, memory consumption, GPU usage, temperature, battery level, disk usage, and network performance
- **Process Monitoring**: Individual application tracking with resource usage and optimization recommendations
- **Network Intelligence**: Dynamic network type detection and switching between 5G, 4G, and WiFi based on conditions
- **Performance Tracking**: SLA monitoring for UI responsiveness and system performance guarantees

### AI Optimization Engine
- **Machine Learning Integration**: Pattern recognition for system behavior analysis and predictive optimization
- **Thermal Management**: Intelligent cooling system with multiple modes (auto, cool, turbo) and emergency cooling protocols
- **Resource Optimization**: Automated suggestions for CPU limiting, process management, and power saving
- **Learning Algorithm**: Adaptive system that improves recommendations based on historical performance data

### Authentication and Session Management
- **Session-Based Authentication**: Traditional server-side session management with PostgreSQL session store
- **User Context**: Protected API routes with user validation and role-based access patterns prepared for implementation

## External Dependencies

### Database and ORM
- **Neon Database**: Serverless PostgreSQL provider for scalable cloud database hosting
- **Drizzle ORM**: Modern TypeScript ORM with excellent type safety and PostgreSQL integration
- **connect-pg-simple**: PostgreSQL session store for Express sessions

### UI and Components
- **Radix UI**: Comprehensive headless component library providing accessible UI primitives
- **shadcn/ui**: Pre-built component library with consistent design system
- **Tailwind CSS**: Utility-first CSS framework for responsive design
- **Lucide React**: Modern icon library with consistent styling

### Real-time Communication
- **WebSocket (ws)**: Native WebSocket implementation for real-time bidirectional communication
- **TanStack Query**: Powerful data synchronization and caching library for React

### Development and Build Tools
- **Vite**: Fast build tool with hot module replacement and optimized production builds
- **TypeScript**: Static type checking across the entire application stack
- **ESBuild**: Fast JavaScript bundler for production builds
- **Replit Integration**: Development environment integration with runtime error overlay and cartographer plugins