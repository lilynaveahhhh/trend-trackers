import { EventEmitter } from 'events';
import { OptimizationSuggestion, ProcessInfo } from '@shared/schema';

export class AIOptimizer extends EventEmitter {
  private learningData: Map<string, number> = new Map();
  private thermalHistory: number[] = [];
  private cpuHistory: number[] = [];

  constructor() {
    super();
  }

  analyzeSystem(metrics: any, processes: ProcessInfo[]): OptimizationSuggestion[] {
    const suggestions: OptimizationSuggestion[] = [];

    // Update history for learning
    this.thermalHistory.push(metrics.temperature);
    this.cpuHistory.push(metrics.cpuUsage);
    
    // Keep only last 100 readings
    if (this.thermalHistory.length > 100) {
      this.thermalHistory.shift();
      this.cpuHistory.shift();
    }

    // Thermal optimization
    if (metrics.temperature > 50) {
      suggestions.push({
        id: this.generateId(),
        timestamp: new Date(),
        type: 'thermal',
        description: 'Reduce CPU frequency during high temperature',
        efficiency: this.calculateThermalEfficiency(metrics.temperature),
        autoApply: false,
        applied: false
      });
    }

    // Network optimization
    if (metrics.batteryLevel < 30) {
      suggestions.push({
        id: this.generateId(),
        timestamp: new Date(),
        type: 'network',
        description: 'Switch to 4G for background apps to save battery',
        efficiency: 8,
        autoApply: false,
        applied: false
      });
    }

    // Process optimization
    const heavyProcesses = processes.filter(p => p.cpuUsage > 10);
    if (heavyProcesses.length > 0 && metrics.temperature > 55) {
      suggestions.push({
        id: this.generateId(),
        timestamp: new Date(),
        type: 'process',
        description: 'Pause non-critical background tasks during thermal stress',
        efficiency: this.calculateProcessEfficiency(heavyProcesses),
        autoApply: false,
        applied: false
      });
    }

    // GPU optimization
    if (metrics.gpuUsage > 80 && metrics.temperature > 60) {
      suggestions.push({
        id: this.generateId(),
        timestamp: new Date(),
        type: 'thermal',
        description: 'Reduce GPU power limit to prevent overheating',
        efficiency: 20,
        autoApply: false,
        applied: false
      });
    }

    // Memory optimization
    if (metrics.memoryUsage / metrics.memoryTotal > 0.8) {
      suggestions.push({
        id: this.generateId(),
        timestamp: new Date(),
        type: 'process',
        description: 'Clear memory caches and compress unused applications',
        efficiency: 15,
        autoApply: false,
        applied: false
      });
    }

    return suggestions;
  }

  predictThermalEvent(currentTemp: number, cpuUsage: number): { risk: number; timeToThreshold: number } {
    if (this.thermalHistory.length < 10) {
      return { risk: 0, timeToThreshold: Infinity };
    }

    // Simple trend analysis
    const recentTemps = this.thermalHistory.slice(-10);
    const tempTrend = recentTemps[recentTemps.length - 1] - recentTemps[0];
    
    // Calculate risk based on current temperature and trend
    let risk = 0;
    if (currentTemp > 60) risk += 30;
    if (currentTemp > 70) risk += 40;
    if (tempTrend > 5) risk += 20;
    if (cpuUsage > 80) risk += 10;

    // Estimate time to dangerous threshold (75°C)
    const threshold = 75;
    let timeToThreshold = Infinity;
    
    if (tempTrend > 0) {
      timeToThreshold = Math.max(0, (threshold - currentTemp) / (tempTrend / 10));
    }

    return { risk: Math.min(100, risk), timeToThreshold };
  }

  learnFromUserBehavior(action: string, context: any) {
    // Simple learning mechanism
    const key = `${action}_${context.temperature}_${context.cpuUsage}`;
    const currentValue = this.learningData.get(key) || 0;
    this.learningData.set(key, currentValue + 1);
  }

  private calculateThermalEfficiency(temperature: number): number {
    // Higher temperature = higher efficiency gain from thermal optimization
    return Math.min(25, Math.max(5, (temperature - 40) * 0.8));
  }

  private calculateProcessEfficiency(processes: ProcessInfo[]): number {
    // Calculate efficiency based on CPU usage of heavy processes
    const totalCPU = processes.reduce((sum, p) => sum + p.cpuUsage, 0);
    return Math.min(20, Math.max(5, totalCPU * 0.3));
  }

  private generateId(): string {
    return Math.random().toString(36).substr(2, 9);
  }

  getOptimizationStrategies(systemState: any) {
    return {
      thermalManagement: {
        cpuThrottling: systemState.temperature > 65,
        fanSpeedIncrease: systemState.temperature > 60,
        backgroundTaskPausing: systemState.temperature > 70
      },
      networkOptimization: {
        prefer4G: systemState.batteryLevel < 25,
        reduceBandwidth: systemState.temperature > 65,
        pauseUpdates: systemState.cpuUsage > 85
      },
      powerManagement: {
        reduceBrightness: systemState.batteryLevel < 20,
        lowerRefreshRate: systemState.temperature > 65,
        disableAnimations: systemState.cpuUsage > 90
      }
    };
  }
}

export const aiOptimizer = new AIOptimizer();
