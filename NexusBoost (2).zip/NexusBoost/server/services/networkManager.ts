import { EventEmitter } from 'events';
import { NetworkInfo } from '@shared/schema';

export class NetworkManager extends EventEmitter {
  private currentNetwork: NetworkInfo;
  private autoSwitchEnabled = true;
  private networkHistory: { type: string; timestamp: Date; reason: string }[] = [];

  constructor() {
    super();
    this.currentNetwork = {
      type: '5G',
      downloadSpeed: 847,
      uploadSpeed: 92,
      signal: 85,
      autoSwitch: true
    };
  }

  getCurrentNetwork(): NetworkInfo {
    return { ...this.currentNetwork };
  }

  switchNetwork(targetType: '5G' | '4G' | 'WiFi', reason: string = 'manual') {
    if (this.currentNetwork.type === targetType) return;

    const previousType = this.currentNetwork.type;
    this.currentNetwork.type = targetType;
    
    // Update speeds based on network type
    switch (targetType) {
      case '5G':
        this.currentNetwork.downloadSpeed = Math.random() * 200 + 600;
        this.currentNetwork.uploadSpeed = Math.random() * 50 + 70;
        this.currentNetwork.signal = Math.random() * 20 + 75;
        break;
      case '4G':
        this.currentNetwork.downloadSpeed = Math.random() * 100 + 200;
        this.currentNetwork.uploadSpeed = Math.random() * 30 + 20;
        this.currentNetwork.signal = Math.random() * 15 + 80;
        break;
      case 'WiFi':
        this.currentNetwork.downloadSpeed = Math.random() * 300 + 400;
        this.currentNetwork.uploadSpeed = Math.random() * 100 + 50;
        this.currentNetwork.signal = Math.random() * 25 + 70;
        break;
    }

    this.networkHistory.push({
      type: targetType,
      timestamp: new Date(),
      reason
    });

    // Keep only last 50 entries
    if (this.networkHistory.length > 50) {
      this.networkHistory.shift();
    }

    this.emit('networkChanged', {
      from: previousType,
      to: targetType,
      reason,
      networkInfo: this.getCurrentNetwork()
    });

    console.log(`Network switched from ${previousType} to ${targetType} (${reason})`);
  }

  analyzeAndOptimize(systemMetrics: any, processes: any[]) {
    if (!this.autoSwitchEnabled) return;

    const { temperature, batteryLevel, cpuUsage } = systemMetrics;
    const currentType = this.currentNetwork.type;

    // Thermal-aware switching
    if (temperature > 65 && currentType === '5G') {
      this.switchNetwork('4G', 'thermal_protection');
      return;
    }

    // Battery-aware switching
    if (batteryLevel < 25 && currentType === '5G') {
      this.switchNetwork('4G', 'battery_conservation');
      return;
    }

    // Performance-based switching
    if (cpuUsage > 85 && currentType === '5G') {
      // Check if we have bandwidth-heavy processes
      const mediApps = processes.filter(p => 
        p.category === 'Media' || p.category === 'Browser'
      );
      
      if (mediApps.length === 0) {
        this.switchNetwork('4G', 'cpu_optimization');
        return;
      }
    }

    // Switch back to 5G when conditions are favorable
    if (currentType === '4G' && temperature < 55 && batteryLevel > 40 && cpuUsage < 60) {
      this.switchNetwork('5G', 'optimal_conditions');
    }
  }

  setAutoSwitch(enabled: boolean) {
    this.autoSwitchEnabled = enabled;
    this.currentNetwork.autoSwitch = enabled;
    this.emit('autoSwitchChanged', enabled);
  }

  getNetworkHistory() {
    return [...this.networkHistory];
  }

  getOptimalNetwork(requirements: {
    bandwidth?: 'low' | 'medium' | 'high';
    latency?: 'low' | 'medium' | 'high';
    powerEfficiency?: 'low' | 'medium' | 'high';
  }): '5G' | '4G' | 'WiFi' {
    const { bandwidth = 'medium', latency = 'medium', powerEfficiency = 'medium' } = requirements;

    // Score each network type
    const scores = {
      '5G': 0,
      '4G': 0,
      'WiFi': 0
    };

    // Bandwidth scoring
    if (bandwidth === 'high') {
      scores['5G'] += 3;
      scores['WiFi'] += 2;
      scores['4G'] += 1;
    } else if (bandwidth === 'medium') {
      scores['5G'] += 2;
      scores['WiFi'] += 3;
      scores['4G'] += 2;
    } else {
      scores['4G'] += 3;
      scores['WiFi'] += 2;
      scores['5G'] += 1;
    }

    // Latency scoring
    if (latency === 'low') {
      scores['5G'] += 3;
      scores['4G'] += 2;
      scores['WiFi'] += 1;
    } else if (latency === 'medium') {
      scores['5G'] += 2;
      scores['4G'] += 2;
      scores['WiFi'] += 2;
    } else {
      scores['WiFi'] += 3;
      scores['4G'] += 2;
      scores['5G'] += 1;
    }

    // Power efficiency scoring
    if (powerEfficiency === 'high') {
      scores['WiFi'] += 3;
      scores['4G'] += 2;
      scores['5G'] += 1;
    } else if (powerEfficiency === 'medium') {
      scores['WiFi'] += 2;
      scores['4G'] += 3;
      scores['5G'] += 2;
    } else {
      scores['5G'] += 3;
      scores['4G'] += 2;
      scores['WiFi'] += 1;
    }

    // Return network with highest score
    const best = Object.entries(scores).reduce((a, b) => 
      scores[a[0] as keyof typeof scores] > scores[b[0] as keyof typeof scores] ? a : b
    );

    return best[0] as '5G' | '4G' | 'WiFi';
  }
}

export const networkManager = new NetworkManager();
