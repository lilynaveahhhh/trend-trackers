import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { systemMonitor } from "./services/systemMonitor";
import { aiOptimizer } from "./services/aiOptimizer";
import { networkManager } from "./services/networkManager";

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);

  // WebSocket server for real-time updates
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  // Store connected clients
  const clients = new Set<WebSocket>();

  wss.on('connection', (ws) => {
    console.log('Client connected to WebSocket');
    clients.add(ws);

    // Send initial data
    const initialData = {
      type: 'initial',
      data: storage.getLatestSystemData()
    };
    
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify(initialData));
    }

    ws.on('message', async (message) => {
      try {
        const data = JSON.parse(message.toString());
        
        switch (data.type) {
          case 'optimizationAction':
            await handleOptimizationAction(data.payload);
            break;
          case 'networkSwitch':
            await handleNetworkSwitch(data.payload);
            break;
          case 'thermalSettings':
            await handleThermalSettings(data.payload);
            break;
          case 'emergencyCooling':
            await handleEmergencyCooling();
            break;
        }
      } catch (error) {
        console.error('WebSocket message error:', error);
      }
    });

    ws.on('close', () => {
      console.log('Client disconnected from WebSocket');
      clients.delete(ws);
    });
  });

  // Broadcast function
  function broadcast(data: any) {
    const message = JSON.stringify(data);
    clients.forEach(client => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(message);
      }
    });
  }

  // System monitoring events
  systemMonitor.on('metrics', (data) => {
    // Store metrics
    storage.storeSystemMetrics(data.metrics);
    
    // Run AI optimization
    const suggestions = aiOptimizer.analyzeSystem(data.metrics, data.metrics.processes);
    storage.storeSuggestions(suggestions);
    
    // Network optimization
    networkManager.analyzeAndOptimize(data.metrics, data.metrics.processes);
    
    // Broadcast to clients
    broadcast({
      type: 'systemUpdate',
      data: {
        metrics: data.metrics,
        networkInfo: data.networkInfo,
        suggestions,
        thermalSettings: storage.getThermalSettings()
      }
    });
  });

  // Network change events
  networkManager.on('networkChanged', (data) => {
    broadcast({
      type: 'networkChanged',
      data
    });
  });

  // REST API routes
  app.get('/api/system/current', (req, res) => {
    res.json(storage.getLatestSystemData());
  });

  app.get('/api/system/history/:hours', (req, res) => {
    const hours = parseInt(req.params.hours) || 1;
    res.json(storage.getSystemHistory(hours));
  });

  app.post('/api/optimization/apply', async (req, res) => {
    try {
      const { suggestionId } = req.body;
      await handleOptimizationAction({ suggestionId });
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: 'Failed to apply optimization' });
    }
  });

  app.post('/api/network/switch', async (req, res) => {
    try {
      const { type } = req.body;
      await handleNetworkSwitch({ type });
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: 'Failed to switch network' });
    }
  });

  app.post('/api/thermal/settings', async (req, res) => {
    try {
      await handleThermalSettings(req.body);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: 'Failed to update thermal settings' });
    }
  });

  app.post('/api/emergency/cooling', async (req, res) => {
    try {
      await handleEmergencyCooling();
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: 'Failed to activate emergency cooling' });
    }
  });

  // Action handlers
  async function handleOptimizationAction(payload: { suggestionId: string }) {
    const suggestion = storage.getSuggestion(payload.suggestionId);
    if (suggestion) {
      storage.applySuggestion(payload.suggestionId);
      
      // Simulate applying the optimization
      console.log(`Applied optimization: ${suggestion.description}`);
      
      broadcast({
        type: 'optimizationApplied',
        data: { suggestion }
      });
    }
  }

  async function handleNetworkSwitch(payload: { type: '5G' | '4G' | 'WiFi' }) {
    networkManager.switchNetwork(payload.type, 'user_request');
  }

  async function handleThermalSettings(settings: any) {
    storage.updateThermalSettings(settings);
    
    broadcast({
      type: 'thermalSettingsUpdated',
      data: settings
    });
  }

  async function handleEmergencyCooling() {
    console.log('Emergency cooling activated');
    
    // Simulate emergency cooling actions
    const emergencyActions = [
      'CPU frequency reduced to 50%',
      'GPU power limit set to 60%',
      'Background processes paused',
      'Display brightness reduced',
      'Network switched to power-saving mode'
    ];
    
    broadcast({
      type: 'emergencyCooling',
      data: { 
        active: true,
        actions: emergencyActions,
        timestamp: new Date()
      }
    });
    
    // Auto-disable after 5 minutes
    setTimeout(() => {
      broadcast({
        type: 'emergencyCooling',
        data: { 
          active: false,
          timestamp: new Date()
        }
      });
    }, 5 * 60 * 1000);
  }

  // Start system monitoring
  systemMonitor.start();

  return httpServer;
}
