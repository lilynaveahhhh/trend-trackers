import { 
  type User, 
  type InsertUser,
  type SystemMetrics,
  type InsertSystemMetrics,
  type OptimizationSuggestion,
  type InsertOptimizationSuggestion,
  type ThermalSettings,
  type InsertThermalSettings,
  type SystemData,
  type NetworkInfo
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  storeSystemMetrics(metrics: InsertSystemMetrics): void;
  getLatestSystemData(): SystemData | null;
  getSystemHistory(hours: number): SystemMetrics[];
  
  storeSuggestions(suggestions: OptimizationSuggestion[]): void;
  getSuggestion(id: string): OptimizationSuggestion | undefined;
  applySuggestion(id: string): void;
  
  getThermalSettings(): ThermalSettings;
  updateThermalSettings(settings: Partial<InsertThermalSettings>): void;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private systemMetrics: SystemMetrics[] = [];
  private suggestions: Map<string, OptimizationSuggestion> = new Map();
  private thermalSettings: ThermalSettings;
  private latestNetworkInfo: NetworkInfo | null = null;

  constructor() {
    this.users = new Map();
    this.thermalSettings = {
      id: randomUUID(),
      coolingMode: 'auto',
      autoOptimization: true,
      thermalThreshold: 65.0,
      emergencyCooling: false
    };
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  storeSystemMetrics(metrics: InsertSystemMetrics): void {
    const systemMetric: SystemMetrics = {
      id: randomUUID(),
      timestamp: new Date(),
      ...metrics
    };
    
    this.systemMetrics.push(systemMetric);
    
    // Keep only last 1000 entries
    if (this.systemMetrics.length > 1000) {
      this.systemMetrics.shift();
    }
  }

  getLatestSystemData(): SystemData | null {
    if (this.systemMetrics.length === 0) return null;
    
    const latestMetrics = this.systemMetrics[this.systemMetrics.length - 1];
    const activeSuggestions = Array.from(this.suggestions.values())
      .filter(s => !s.applied)
      .slice(-5); // Get last 5 suggestions
    
    return {
      metrics: latestMetrics,
      networkInfo: this.latestNetworkInfo || {
        type: '5G',
        downloadSpeed: 847,
        uploadSpeed: 92,
        signal: 85,
        autoSwitch: true
      },
      suggestions: activeSuggestions,
      thermalSettings: this.thermalSettings
    };
  }

  getSystemHistory(hours: number): SystemMetrics[] {
    const cutoffTime = new Date();
    cutoffTime.setHours(cutoffTime.getHours() - hours);
    
    return this.systemMetrics.filter(metric => 
      metric.timestamp >= cutoffTime
    );
  }

  storeSuggestions(suggestions: OptimizationSuggestion[]): void {
    suggestions.forEach(suggestion => {
      this.suggestions.set(suggestion.id, suggestion);
    });
  }

  getSuggestion(id: string): OptimizationSuggestion | undefined {
    return this.suggestions.get(id);
  }

  applySuggestion(id: string): void {
    const suggestion = this.suggestions.get(id);
    if (suggestion) {
      suggestion.applied = true;
      this.suggestions.set(id, suggestion);
    }
  }

  getThermalSettings(): ThermalSettings {
    return { ...this.thermalSettings };
  }

  updateThermalSettings(settings: Partial<InsertThermalSettings>): void {
    this.thermalSettings = {
      ...this.thermalSettings,
      ...settings
    };
  }

  updateNetworkInfo(networkInfo: NetworkInfo): void {
    this.latestNetworkInfo = { ...networkInfo };
  }
}

export const storage = new MemStorage();
